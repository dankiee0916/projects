// -------------------------------------------------------------------
//                          Contact Page
// -------------------------------------------------------------------

// Function to handle a mouseover event
function handleMouseOver() {
    console.log("Mouse over the link!");
}

// Function to handle button click and toggle visibility of the social links
function handleButtonClick() {
    $(".social-links").toggle(); // Use jQuery to toggle the visibility
}

// Attach event listeners to elements when the DOM is fully loaded
$(document).ready(function () {
    // Check if the button exists on the page before adding the event listener
    var buttonElement = $("#myButton");
    if (buttonElement.length) {
        buttonElement.on("click", handleButtonClick);
    }

    // Check if the link exists on the page before adding the event listener
    var linkElement = $("#myLink");
    if (linkElement.length) {
        linkElement.on("mouseover", handleMouseOver);
    }
});


$(document).ready(function () {
    // Toggle the visibility of the YouTube video on button click
    $('#toggleVideo').click(function () {
        $('#youtube-video').toggle();
    });
});