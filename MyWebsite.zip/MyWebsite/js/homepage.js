// Francisco Gonzalez
// CST-120
// Milestone 5
// 11/19/2023
// This is my own work


// -------------------------------------------------------------------
//                          Home Page
// -------------------------------------------------------------------

// Function to handle click events on the "Home" link
function handleHomeLinkClick() {
    alert("You clicked the Home link!");
    // Add more functionality as needed
}

// Function to handle mouseover events on the "About Me" link
function handleAboutMeMouseOver() {
    alert("Mouseover on the About Me link!");
    // Add more functionality as needed
}

// Function to handle keydown events on the "Hobbies" link
function handleHobbiesKeyDown() {
    alert("Keydown on the Hobbies link!");
    // Add more functionality as needed
}

// Function to handle double click events on the "Pictures" link
function handlePicturesDoubleClick() {
    alert("Double click on the Pictures link!");
    // Add more functionality as needed
}

// Function to handle contextmenu events on the "Socials" link
function handleSocialsContextMenu(event) {
    event.preventDefault();
    alert("Right-click on the Socials link!");
    // Add more functionality as needed
}

// Add more functions and events as needed

// Attach event handlers to elements on the page

// Home link click event
document.querySelector('h2 a[href="homepage.html"]').addEventListener('click', handleHomeLinkClick);

// About Me link mouseover event
document.querySelector('h2 a[href="pages/aboutme.html"]').addEventListener('mouseover', handleAboutMeMouseOver);

// Hobbies link keydown event
document.querySelector('h2 a[href="pages/hobbies.html"]').addEventListener('keydown', handleHobbiesKeyDown);

// Pictures link double click event
document.querySelector('h2 a[href="pages/photography.html"]').addEventListener('dblclick', handlePicturesDoubleClick);

// Socials link contextmenu event
document.querySelector('h2 a[href="pages/contact.html"]').addEventListener('contextmenu', handleSocialsContextMenu);

// Function to handle a click event
function handleButtonClick() {
    alert("Button clicked!");
}

