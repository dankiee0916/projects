public class Main {
    public static void main(String[] args) {
        InventoryManager inventoryManager = new InventoryManager();
        StoreServer storeServer = new StoreServer(inventoryManager);
        Thread serverThread = new Thread(storeServer);
        serverThread.start();

        // Optionally, start the StoreFront application as well
        StoreFront storeFront = new StoreFront();
        storeFront.run();
    }
}
