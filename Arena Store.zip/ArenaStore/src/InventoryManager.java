import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    private List<SalableProduct> inventory;

    public InventoryManager() {
        inventory = FileService.loadInventory();
        if (inventory == null) {
            inventory = new ArrayList<>();
        }
    }

    // Adds a product to the inventory
    public void addProduct(SalableProduct product) {
        inventory.add(product);
    }

    // Removes a product from the inventory
    public void removeProduct(SalableProduct product) {
        inventory.remove(product);
    }

    // Updates a product in the inventory
    public void updateProduct(SalableProduct updatedProduct) {
        for (int i = 0; i < inventory.size(); i++) {
            SalableProduct product = inventory.get(i);
            if (product.getName().equalsIgnoreCase(updatedProduct.getName())) {
                inventory.set(i, updatedProduct);
                return;
            }
        }
        // If the product does not exist, add it to the inventory
        addProduct(updatedProduct);
    }

    // Gets the current inventory
    public List<SalableProduct> getInventory() {
        return inventory;
    }

    // Sorts the inventory by product name
    public void sortByName() {
        inventory.sort((p1, p2) -> p1.getName().compareToIgnoreCase(p2.getName()));
    }

    // Sorts the inventory by product price
    public void sortByPrice() {
        inventory.sort((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()));
    }
}
