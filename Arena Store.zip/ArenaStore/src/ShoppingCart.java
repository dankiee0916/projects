import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<SalableProduct> cart;

    public ShoppingCart() {
        cart = new ArrayList<>();
    }

    // Adds a product to the shopping cart
    public void addProduct(SalableProduct product) {
        cart.add(product);
    }

    // Removes a product from the shopping cart
    public void removeProduct(SalableProduct product) {
        cart.remove(product);
    }

    // Returns the contents of the shopping cart
    public List<SalableProduct> getCart() {
        return cart;
    }

    // Empties the shopping cart
    public void emptyCart() {
        cart.clear();
    }
}
