import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SalableProductTest {
    private SalableProduct product;

    // This method sets up the test environment before each test case is run
    @BeforeEach
    public void setUp() {
        product = new SalableProduct("Diamond Longsword", "A sword made of diamond.", 150.0, 5);
    }

    // Test for getting the name of the product
    @Test
    public void testGetName() {
        assertEquals("Diamond Longsword", product.getName()); // Verify that the product name is correctly retrieved
    }

    // Test for getting the description of the product
    @Test
    public void testGetDescription() {
        assertEquals("A sword made of diamond.", product.getDescription()); // Verify that the product description is correctly retrieved
    }

    // Test for getting the price of the product
    @Test
    public void testGetPrice() {
        assertEquals(150.0, product.getPrice()); // Verify that the product price is correctly retrieved
    }

    // Test for getting the quantity of the product
    @Test
    public void testGetQuantity() {
        assertEquals(5, product.getQuantity()); // Verify that the product quantity is correctly retrieved
    }

    // Test for setting the name of the product
    @Test
    public void testSetName() {
        product.setName("Emerald Longsword"); // Set a new name for the product
        assertEquals("Emerald Longsword", product.getName()); // Verify that the product name was correctly updated
    }

    // Test for setting the description of the product
    @Test
    public void testSetDescription() {
        product.setDescription("A sword made of emerald."); // Set a new description for the product
        assertEquals("A sword made of emerald.", product.getDescription()); // Verify that the product description was correctly updated
    }

    // Test for setting the price of the product
    @Test
    public void testSetPrice() {
        product.setPrice(200.0); // Set a new price for the product
        assertEquals(200.0, product.getPrice()); // Verify that the product price was correctly updated
    }

    // Test for setting the quantity of the product
    @Test
    public void testSetQuantity() {
        product.setQuantity(10); // Set a new quantity for the product
        assertEquals(10, product.getQuantity()); // Verify that the product quantity was correctly updated
    }
}
