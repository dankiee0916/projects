import java.io.*;
import java.net.*;
import java.util.*;

public class Admin {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) {
        Admin admin = new Admin();
        admin.run();
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        String command;

        System.out.println("Welcome to the Administration Application!");
        do {
            displayMenu();
            command = scanner.nextLine();

            switch (command.toUpperCase()) {
                case "U":
                    updateInventory(scanner);
                    break;
                case "R":
                    requestInventory();
                    break;
                case "Q":
                    System.out.println("Exiting the Administration Application. Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (!command.equalsIgnoreCase("Q"));
    }

    private void displayMenu() {
        System.out.println("Menu:");
        System.out.println("U - Update Inventory");
        System.out.println("R - Request Inventory");
        System.out.println("Q - Quit");
        System.out.print("Enter your choice: ");
    }

    private void updateInventory(Scanner scanner) {
        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            System.out.println("Enter inventory data in JSON format:");
            String json = scanner.nextLine();
            out.println("U|" + json);
            System.out.println("Response: " + in.readLine());

        } catch (IOException e) {
            System.err.println("Error updating inventory: " + e.getMessage());
        }
    }

    private void requestInventory() {
        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println("R");
            String response = in.readLine();
            System.out.println("Inventory: " + response);

        } catch (IOException e) {
            System.err.println("Error requesting inventory: " + e.getMessage());
        }
    }
}
