import java.io.*;
import java.net.*;
import java.util.*;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

public class StoreServer implements Runnable {
    private InventoryManager inventoryManager;

    public StoreServer(InventoryManager inventoryManager) {
        this.inventoryManager = inventoryManager;
    }

    @Override
    public void run() {
        // Start the server socket to listen for admin commands
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Store Server started on port 12345");

            // Continuously listen for client connections
            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                     PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                    String request = in.readLine(); // Read the incoming request
                    if (request != null) {
                        handleRequest(request, out); // Handle the request
                    }
                } catch (IOException e) {
                    System.err.println("Error in Store Server: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Error starting Store Server: " + e.getMessage());
        }
    }

    // Method to handle incoming requests
    private void handleRequest(String request, PrintWriter out) {
        String[] parts = request.split("\\|"); // Split the request by '|'
        String command = parts[0];
        String data = parts.length > 1 ? parts[1] : "";

        switch (command) {
            case "U": // Update inventory command
                updateInventory(data);
                out.println("Inventory updated.");
                break;
            case "R": // Return inventory command
                String inventoryJson = new Gson().toJson(inventoryManager.getInventory());
                out.println(inventoryJson);
                break;
            default:
                out.println("Unknown command.");
                break;
        }
    }

    // Method to update the inventory
    private void updateInventory(String data) {
        List<SalableProduct> products = new Gson().fromJson(data, new TypeToken<List<SalableProduct>>(){}.getType());
        for (SalableProduct product : products) {
            inventoryManager.updateProduct(product);
        }
    }
}
