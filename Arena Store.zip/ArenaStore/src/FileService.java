import java.io.*;
import java.util.List;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

public class FileService {
    private static final String FILE_PATH = "inventory.json";

    public static void saveInventory(List<SalableProduct> inventory) {
        try (Writer writer = new FileWriter(FILE_PATH)) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(inventory, writer);
        } catch (IOException e) {
            System.err.println("Error saving inventory: " + e.getMessage());
        }
    }

    public static List<SalableProduct> loadInventory() {
        try (Reader reader = new FileReader(FILE_PATH)) {
            Gson gson = new Gson();
            return gson.fromJson(reader, new TypeToken<List<SalableProduct>>(){}.getType());
        } catch (IOException e) {
            System.err.println("Error loading inventory: " + e.getMessage());
            return null;
        }
    }
}
