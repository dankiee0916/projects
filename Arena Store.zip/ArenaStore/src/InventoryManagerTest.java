import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;

public class InventoryManagerTest {
    private InventoryManager inventoryManager;
    private SalableProduct product1;
    private SalableProduct product2;

    // This method sets up the test environment before each test case is run
    @BeforeEach
    public void setUp() {
        inventoryManager = new InventoryManager();
        inventoryManager.getInventory().clear(); // Clear the inventory before each test to ensure a clean state
        product1 = new SalableProduct("Diamond Longsword", "A sword made of diamond.", 150.0, 5);
        product2 = new SalableProduct("Speedy Flash Boots", "Boots that increase speed.", 75.0, 7);
        inventoryManager.addProduct(product1); // Add first test product to inventory
        inventoryManager.addProduct(product2); // Add second test product to inventory
    }

    // Test for adding a product to the inventory
    @Test
    public void testAddProduct() {
        SalableProduct product3 = new SalableProduct("Sturdy Iron Chestplate", "A sturdy iron chestplate.", 100.0, 3);
        inventoryManager.addProduct(product3); // Add a new product to the inventory
        assertTrue(inventoryManager.getInventory().contains(product3)); // Verify that the product was added successfully
    }

    // Test for removing a product from the inventory
    @Test
    public void testRemoveProduct() {
        inventoryManager.removeProduct(product1); // Remove an existing product from the inventory
        assertFalse(inventoryManager.getInventory().contains(product1)); // Verify that the product was removed successfully
    }

    // Test for retrieving the current inventory
    @Test
    public void testGetInventory() {
        assertEquals(2, inventoryManager.getInventory().size()); // Verify that the inventory contains 2 products
    }

    // Test for sorting the inventory by product name
    @Test
    public void testSortByName() {
        inventoryManager.sortByName(); // Sort the inventory by product name
        List<SalableProduct> sortedInventory = inventoryManager.getInventory(); // Retrieve the sorted inventory
        assertEquals("Diamond Longsword", sortedInventory.get(0).getName()); // Verify that the first product is sorted correctly
        assertEquals("Speedy Flash Boots", sortedInventory.get(1).getName()); // Verify that the second product is sorted correctly
    }

    // Test for sorting the inventory by product price
    @Test
    public void testSortByPrice() {
        SalableProduct product3 = new SalableProduct("Steak", "A yummy piece of steak that restores 10% health.", 15.0, 20);
        SalableProduct product4 = new SalableProduct("Sturdy Iron Chestplate", "A sturdy iron chestplate.", 100.0, 3);
        inventoryManager.addProduct(product3); // Add a cheaper product to the inventory
        inventoryManager.addProduct(product4); // Add a product with a price between the existing products
        inventoryManager.sortByPrice(); // Sort the inventory by product price
        List<SalableProduct> sortedInventory = inventoryManager.getInventory(); // Retrieve the sorted inventory
        assertEquals("Steak", sortedInventory.get(0).getName()); // Verify that the cheapest product is first
        assertEquals("Speedy Flash Boots", sortedInventory.get(1).getName()); // Verify that the next cheapest product is second
        assertEquals("Sturdy Iron Chestplate", sortedInventory.get(2).getName()); // Verify that the product in the middle price range is third
        assertEquals("Diamond Longsword", sortedInventory.get(3).getName()); // Verify that the most expensive product is last
    }
}
