import java.util.Scanner;

public class StoreFront {
    private InventoryManager inventoryManager;
    private ShoppingCart shoppingCart;
    private Scanner scanner;

    // Constructor initializes the inventory manager, shopping cart, and scanner
    public StoreFront() {
        inventoryManager = new InventoryManager();
        shoppingCart = new ShoppingCart();
        scanner = new Scanner(System.in);
    }

    // Runs the StoreFront application
    public void run() {
        System.out.println("Welcome to the Store Front!");
        boolean running = true;

        // Main loop for the StoreFront application
        while (running) {
            System.out.println("Select an option:");
            System.out.println("1. View Products");
            System.out.println("2. Purchase Product");
            System.out.println("3. View Cart");
            System.out.println("4. Checkout");
            System.out.println("5. Exit");

            try {
                int choice = Integer.parseInt(scanner.nextLine()); // Read user input

                switch (choice) {
                    case 1:
                        viewProducts(); // View available products
                        break;
                    case 2:
                        purchaseProduct(); // Purchase a product
                        break;
                    case 3:
                        viewCart(); // View the contents of the shopping cart
                        break;
                    case 4:
                        checkout(); // Checkout and show the total
                        break;
                    case 5:
                        FileService.saveInventory(inventoryManager.getInventory()); // Save the current inventory to a file
                        running = false; // Exit the application
                        break;
                    default:
                        System.out.println("Invalid choice."); // Handle invalid menu options
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number."); // Handle invalid input
            }
        }
    }

    // Displays all available products
    private void viewProducts() {
        System.out.println("Available products:");
        for (SalableProduct product : inventoryManager.getInventory()) {
            System.out.println(product.getName() + " - $" + product.getPrice()); // Print product details
        }
    }

    // Handles the purchase of a product
    private void purchaseProduct() {
        System.out.println("Enter the name of the product to purchase:");
        String name = scanner.nextLine().trim();
        SalableProduct product = findProductByName(name); // Find the product by name

        if (product != null) {
            shoppingCart.addProduct(product); // Add product to the shopping cart
            inventoryManager.removeProduct(product); // Remove product from inventory
            System.out.println("Product added to cart.");
        } else {
            System.out.println("Product not found."); // Handle product not found
        }
    }

    // Displays the contents of the shopping cart
    private void viewCart() {
        System.out.println("Shopping cart contents:");
        for (SalableProduct product : shoppingCart.getCart()) {
            System.out.println(product.getName() + " - $" + product.getPrice()); // Print product details
        }
    }

    // Handles the checkout process
    private void checkout() {
        System.out.println("Checking out...");
        double total = 0;
        for (SalableProduct product : shoppingCart.getCart()) {
            total += product.getPrice(); // Calculate the total price
        }
        System.out.println("Total: $" + total); // Print the total price
        shoppingCart.emptyCart(); // Empty the shopping cart after checkout
    }

    // Finds a product in the inventory by its name
    private SalableProduct findProductByName(String name) {
        for (SalableProduct product : inventoryManager.getInventory()) {
            if (product.getName().equalsIgnoreCase(name.trim())) {
                return product; // Return the product if found
            }
        }
        return null; // Return null if the product is not found
    }
}
