﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace CiscosStore
{
    internal class ProductsDAO
    {
        string connectionString = "datasource=localhost;port=3306;username=root;password=root;database=ciscosstore;";

        public List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlCommand command = new MySqlCommand("SELECT productID, productName, price, categoryID FROM products", connection);
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new Product
                        {
                            ID = reader.GetInt32("productID"),
                            Name = reader.GetString("productName"),
                            Price = reader.GetDecimal("price"),
                            CategoryID = reader.GetInt32("categoryID") 
                        });
                    }
                }
            }
            return products;
        }

        public int AddProduct(Product product)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlCommand command = new MySqlCommand(
                    "INSERT INTO products (productID, productName, price, categoryID) VALUES (@id, @name, @price, @categoryID)", connection);
                command.Parameters.AddWithValue("@id", product.ID);
                command.Parameters.AddWithValue("@name", product.Name);
                command.Parameters.AddWithValue("@price", product.Price);
                command.Parameters.AddWithValue("@categoryID", product.CategoryID);  // Include category ID
                return command.ExecuteNonQuery();
            }
        }

        public List<Product> SearchProducts(string searchTerm)
        {
            List<Product> products = new List<Product>();
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string searchWildcard = "%" + searchTerm + "%";
                MySqlCommand command = new MySqlCommand("SELECT * FROM products WHERE productName LIKE @search", connection);
                command.Parameters.AddWithValue("@search", searchWildcard);
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new Product
                        {
                            ID = reader.GetInt32("productID"),
                            Name = reader.GetString("productName"),
                            Price = reader.GetDecimal("price")
                        });
                    }
                }
            }
            return products;
        }

        public int DeleteProduct(int productId)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlCommand command = new MySqlCommand("DELETE FROM products WHERE productID = @id", connection);
                command.Parameters.AddWithValue("@id", productId);
                return command.ExecuteNonQuery();
            }
        }
    }
}
