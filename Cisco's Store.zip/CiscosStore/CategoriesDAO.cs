﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace CiscosStore
{
    internal class CategoriesDAO
    {
        string connectionString = "datasource=localhost;port=3306;username=root;password=root;database=ciscosstore;";

        public List<Category> GetAllCategories()
        {
            List<Category> categories = new List<Category>();
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlCommand command = new MySqlCommand("SELECT * FROM productcategories", connection);
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new Category
                        {
                            ID = reader.GetInt32("categoryID"),
                            Name = reader.GetString("categoryName"),
                            Description = reader.GetString("categoryDesc")
                        });
                    }
                }
            }
            return categories;
        }

        public int AddCategory(Category category)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlCommand command = new MySqlCommand("INSERT INTO productcategories (categoryID, categoryName, categoryDesc) VALUES (@id, @name, @desc)", connection);
                command.Parameters.AddWithValue("@id", category.ID);
                command.Parameters.AddWithValue("@name", category.Name);
                command.Parameters.AddWithValue("@desc", category.Description);
                return command.ExecuteNonQuery();
            }
        }

        public List<Category> SearchCategories(string searchTerm)
        {
            List<Category> categories = new List<Category>();
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string searchWildcard = "%" + searchTerm + "%";
                MySqlCommand command = new MySqlCommand("SELECT * FROM productcategories WHERE categoryName LIKE @search", connection);
                command.Parameters.AddWithValue("@search", searchWildcard);
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new Category
                        {
                            ID = reader.GetInt32("categoryID"),
                            Name = reader.GetString("categoryName"),
                            Description = reader.GetString("categoryDesc")
                        });
                    }
                }
            }
            return categories;
        }

        public int DeleteCategory(int categoryId)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlCommand command = new MySqlCommand("DELETE FROM productcategories WHERE categoryID = @id", connection);
                command.Parameters.AddWithValue("@id", categoryId);
                return command.ExecuteNonQuery();
            }
        }
    }
}
