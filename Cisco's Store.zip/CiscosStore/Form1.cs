﻿using CiscosStore;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CiscosStore
{
    public partial class Form1 : Form
    {
        // Binding sources for data grids
        BindingSource categoryBindingSource = new BindingSource();
        BindingSource productBindingSource = new BindingSource();

        // Data access objects
        CategoriesDAO categoriesDAO = new CategoriesDAO();
        ProductsDAO productsDAO = new ProductsDAO();

        public Form1()
        {
            InitializeComponent();
            dgvCategories.DataSource = categoryBindingSource;
            dgvProducts.DataSource = productBindingSource;
        }
        // ---------------------- CATEGORIES ------------------------- //
        private void btnShowAllC_Click(object sender, EventArgs e)
        {
            // Fetch all categories and bind to the data grid view
            List<Category> categories = categoriesDAO.GetAllCategories();
            categoryBindingSource.DataSource = categories;
        }

        private void btnAddC_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtCategoryID.Text, out int categoryID))
            {
                // Add new category with specified ID
                Category category = new Category
                {
                    ID = categoryID,
                    Name = txtNameC.Text,
                    Description = txtDesc.Text
                };

                int result = categoriesDAO.AddCategory(category);
                if (result > 0)
                {
                    MessageBox.Show("Category added successfully.");
                    btnShowAllC_Click(sender, e); // Refresh the list
                }
                else
                {
                    MessageBox.Show("Error adding category.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid numeric Category ID.");
            }
        }
    

        private void btnSearchC_Click(object sender, EventArgs e)
        {
            // Search for categories by name
            string searchTerm = txtSearchAllC.Text;
            List<Category> categories = categoriesDAO.SearchCategories(searchTerm);
            categoryBindingSource.DataSource = categories;
        }

        private void btnDeleteC_Click(object sender, EventArgs e)
        {
            // Delete selected category
            if (dgvCategories.CurrentRow != null)
            {
                int categoryId = (int)dgvCategories.CurrentRow.Cells["ID"].Value;
                int result = categoriesDAO.DeleteCategory(categoryId);
                if (result > 0)
                {
                    MessageBox.Show("Category deleted successfully.");
                    btnShowAllC_Click(sender, e); // Refresh the list
                }
                else
                {
                    MessageBox.Show("Error deleting category.");
                }
            }
            else
            {
                MessageBox.Show("Please select a category to delete.");
            }
        }
        // ---------------------- CATEGORIES ------------------------- //
        // ----------------------  PRODUCTS  ------------------------- //
        private void btnShowAllP_Click(object sender, EventArgs e)
        {
            // Fetch all products and bind to the data grid view
            List<Product> products = productsDAO.GetAllProducts();
            productBindingSource.DataSource = products;
        }

        private void btnAddP_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtProductID.Text, out int productID) &&
                decimal.TryParse(txtPrice.Text, out decimal price) &&
                int.TryParse(txtCategoryIDP.Text, out int categoryID))  // Get category ID
            {
                // Add new product with specified ID, price, and category ID
                Product product = new Product
                {
                    ID = productID,
                    Name = txtNameP.Text,
                    Price = price,
                    CategoryID = categoryID  // Assign category ID
                };

                int result = productsDAO.AddProduct(product);
                if (result > 0)
                {
                    MessageBox.Show("Product added successfully.");
                    btnShowAllP_Click(sender, e); // Refresh the list
                }
                else
                {
                    MessageBox.Show("Error adding product.");
                }
            }
            else
            {
                MessageBox.Show("Please enter valid numeric values for Product ID, Price, and Category ID.");
            }
        }

        private void btnSearchP_Click(object sender, EventArgs e)
        {
            // Search for products by name
            string searchTerm = txtSearchAllP.Text;
            List<Product> products = productsDAO.SearchProducts(searchTerm);
            productBindingSource.DataSource = products;
        }

        private void btnDeleteP_Click(object sender, EventArgs e)
        {
            // Delete selected product
            if (dgvProducts.CurrentRow != null)
            {
                int productId = (int)dgvProducts.CurrentRow.Cells["ID"].Value;
                int result = productsDAO.DeleteProduct(productId);
                if (result > 0)
                {
                    MessageBox.Show("Product deleted successfully.");
                    btnShowAllP_Click(sender, e); // Refresh the list
                }
                else
                {
                    MessageBox.Show("Error deleting product.");
                }
            }
            else
            {
                MessageBox.Show("Please select a product to delete.");
            }
        }

        // ----------------------  PRODUCTS  ------------------------- //

    }
}
