﻿$(document).ready(function () {
    // Handle left-click with AJAX
    $(document).on('click', '.cell', function (e) {
        e.preventDefault(); // Prevent form submission

        // Get row and column from the clicked cell
        const row = $(this).data('row');
        const col = $(this).data('col');

        // AJAX call to update the cell (left-click functionality)
        $.ajax({
            url: '/Game/ButtonLeftClick',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ row: row, col: col }),
            success: function (response) {
                // Select the cell in the grid
                const cellSelector = `[data-row=${response.row}][data-col=${response.col}]`;

                // Update the cell based on the response
                if (response.buttonImage) {
                    $(cellSelector).html(`<img src="/img/${response.buttonImage}" alt="Cell">`);
                } else if (response.visited) {
                    $(cellSelector).html(response.liveNeighbors > 0 ? response.liveNeighbors : "");
                }

                // Update the message
                $('h2').last().text(response.message);

                // If the game is over, disable all cells
                if (response.gameState !== 0) {
                    $('.cell').prop('disabled', true);
                }
            },
            error: function (xhr, status, error) {
                console.error('Error during AJAX request:', error);
            }
        });
    });

    // Handle right-click with AJAX
    $(document).on('contextmenu', '.cell', function (e) {
        e.preventDefault(); // Prevent default browser context menu

        // Get row and column from the clicked cell
        const row = $(this).data('row');
        const col = $(this).data('col');

        // AJAX call to toggle flag (right-click functionality)
        $.ajax({
            url: '/Game/ButtonRightClick',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ row: row, col: col }),
            success: function (response) {
                // Select the cell in the grid
                const cellSelector = `[data-row=${row}][data-col=${col}]`;

                // Update the cell with the flag image
                if (response.buttonImage) {
                    $(cellSelector).html(`<img src="/img/${response.buttonImage}" alt="Flag">`);
                } else {
                    $(cellSelector).html('');
                }
            },
            error: function (xhr, status, error) {
                console.error('Error during AJAX request:', error);
            }
        });
    });
});
