﻿using System;

namespace Minesweeper
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize a board with specified size and difficulty
            Board gameBoard = new Board(10, 0.15f); // 10x10 board, 15% bombs

            // Set up and compute live neighbors
            gameBoard.SetupLiveNeighbors();
            gameBoard.CalculateLiveNeighbors();

            // Start the game loop
            PlayGame(gameBoard);
        }

        // Helper method to print the board to the console during the game
        static void PrintBoardDuringGame(Board board)
        {
            // Print column numbers
            Console.Write("   ");
            for (int col = 0; col < board.Size; col++)
            {
                Console.Write($" {col} ");
            }
            Console.WriteLine();

            // Print horizontal line
            Console.Write("  ");
            for (int col = 0; col < board.Size; col++)
            {
                Console.Write("---");
            }
            Console.WriteLine();

            // Print the board with row numbers and vertical separators
            for (int row = 0; row < board.Size; row++)
            {
                Console.Write($"{row:D2}|");
                for (int col = 0; col < board.Size; col++)
                {
                    // Print '?' for unvisited cells, otherwise print live neighbor count or empty space
                    if (!board.Grid[row, col].Visited)
                        Console.Write(" ? ");
                    else
                        Console.Write(board.Grid[row, col].LiveNeighbors > 0 ? $" {board.Grid[row, col].LiveNeighbors} " : "   ");
                }
                Console.WriteLine();
            }

            // Print horizontal line between rows
            Console.Write("  ");
            for (int col = 0; col < board.Size; col++)
            {
                Console.Write("---");
            }
            Console.WriteLine();
        }

        // Method to handle the game loop
        static void PlayGame(Board board)
        {
            bool gameOver = false;
            int cellsToReveal = board.Size * board.Size - (int)(board.Size * board.Size * board.Difficulty);

            while (!gameOver)
            {
                Console.Clear();
                PrintBoardDuringGame(board);
                int row = GetValidInput("Enter a Row Number: ", board.Size);
                int col = GetValidInput("Enter a Column Number: ", board.Size);

                if (board.Grid[row, col].Live)
                {
                    gameOver = true;
                    Console.Clear();
                    PrintBoard(board);
                    Console.WriteLine("Boom! You hit a bomb. Game over.");
                }
                else
                {
                    Console.WriteLine($"Flood filling from cell ({row}, {col})");
                    board.FloodFill(row, col); // Use the flood fill method
                    cellsToReveal--;

                    if (board.AllNonBombCellsRevealed())
                    {
                        gameOver = true;
                        Console.Clear();
                        PrintBoard(board);
                        Console.WriteLine("Congratulations! You've cleared all safe cells. You win!");
                    }
                }
            }
        }

        // Method to get valid input from the user
        static int GetValidInput(string prompt, int max)
        {
            int result;
            string input;
            do
            {
                Console.Write(prompt);
                input = Console.ReadLine();
            } while (!int.TryParse(input, out result) || result < 0 || result >= max);

            return result;
        }

        // Helper method to print the board to the console
        static void PrintBoard(Board board)
        {
            // Print column numbers
            Console.Write("   ");
            for (int col = 0; col < board.Size; col++)
            {
                Console.Write($" {col} ");
            }
            Console.WriteLine();

            // Print horizontal line
            Console.Write("  ");
            for (int col = 0; col < board.Size; col++)
            {
                Console.Write("---");
            }
            Console.WriteLine();

            // Print the board with row numbers and vertical separators
            for (int row = 0; row < board.Size; row++)
            {
                Console.Write($"{row:D2}|");
                for (int col = 0; col < board.Size; col++)
                {
                    // Print '*' for bombs and '.' for safe cells
                    Console.Write(board.Grid[row, col].Live ? " * " : " . ");
                }
                Console.WriteLine();
            }

            // Print horizontal line between rows
            Console.Write("  ");
            for (int col = 0; col < board.Size; col++)
            {
                Console.Write("---");
            }
            Console.WriteLine();
        }
    }
}
