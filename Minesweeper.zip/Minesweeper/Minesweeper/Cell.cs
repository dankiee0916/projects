﻿using System;

namespace Minesweeper
{
    public class Cell
    {
        public int Row { get; set; } = -1; // Row position of the cell
        public int Column { get; set; } = -1; // Column position of the cell
        public bool Visited { get; set; } = false; // If the cell has been visited
        public bool Live { get; set; } = false; // If the cell contains a live bomb
        public int LiveNeighbors { get; set; } = 0; // Number of live neighbors

        // Constructor to initialize a cell with its row and column
        public Cell(int row, int column)
        {
            Row = row;
            Column = column;
        }
    }
}
