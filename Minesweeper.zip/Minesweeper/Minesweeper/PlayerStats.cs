﻿public class PlayerStats
{
    public string PlayerInitials { get; set; }
    public string DifficultyLevel { get; set; }
    public TimeSpan TimeElapsed { get; set; }
    public int Score { get; set; }
    public bool IsWin { get; set; } // New property to track if the game was a win

    public PlayerStats(string initials, string difficulty, TimeSpan time, int score, bool isWin)
    {
        PlayerInitials = initials;
        DifficultyLevel = difficulty;
        TimeElapsed = time;
        Score = score;
        IsWin = isWin;
    }

    public override string ToString()
    {
        return $"{PlayerInitials} - {DifficultyLevel} - Time: {TimeElapsed} - Score: {Score} - {(IsWin ? "Win" : "Loss")}";
    }
}
