﻿using System;

namespace Minesweeper
{
    public class Board
    {
        public int Size { get; private set; } // Size of the board
        public Cell[,] Grid { get; private set; } // 2D array of cells
        public float Difficulty { get; set; } // Difficulty level of the game

        // Constructor to create a grid of cells
        public Board(int size, float difficulty)
        {
            Size = size;
            Difficulty = difficulty;
            Grid = new Cell[size, size];

            // Populate grid with Cell instances
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    Grid[i, j] = new Cell(i, j);
                }
            }
        }

        // Setup random live bombs based on difficulty
        public void SetupLiveNeighbors()
        {
            Random random = new Random();
            int liveCellsCount = (int)(Size * Size * Difficulty); // Calculate total live cells

            while (liveCellsCount > 0)
            {
                int i = random.Next(Size);
                int j = random.Next(Size);

                // Set cell as live if not already live
                if (!Grid[i, j].Live)
                {
                    Grid[i, j].Live = true;
                    liveCellsCount--;
                }
            }
        }

        // Calculate the number of live neighbors for each cell
        public void CalculateLiveNeighbors()
        {
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    if (Grid[i, j].Live)
                    {
                        Grid[i, j].LiveNeighbors = 9; // Bomb cell marked distinctively
                        continue;
                    }

                    int liveCount = 0;
                    for (int di = -1; di <= 1; di++)
                    {
                        for (int dj = -1; dj <= 1; dj++)
                        {
                            int ni = i + di, nj = j + dj;
                            if (ni >= 0 && ni < Size && nj >= 0 && nj < Size && Grid[ni, nj].Live)
                                liveCount++;
                        }
                    }

                    Grid[i, j].LiveNeighbors = liveCount; // Update neighbor count
                }
            }
        }

        // New FloodFill method to reveal cells recursively
        public void FloodFill(int row, int col)
        {
            if (row < 0 || row >= Size || col < 0 || col >= Size || Grid[row, col].Visited)
                return;

            Grid[row, col].Visited = true;
            Console.WriteLine($"Revealed cell at {row}, {col} with {Grid[row, col].LiveNeighbors} live neighbors");

            // If the cell has no live neighbors, reveal surrounding cells recursively
            if (Grid[row, col].LiveNeighbors == 0)
            {
                for (int i = -1; i <= 1; i++)
                {
                    for (int j = -1; j <= 1; j++)
                    {
                        if (i != 0 || j != 0)
                        {
                            FloodFill(row + i, col + j);
                        }
                    }
                }
            }
        }

        // Method to check if all non-bomb cells are revealed
        public bool AllNonBombCellsRevealed()
        {
            int cellsToReveal = Size * Size - (int)(Size * Size * Difficulty);
            int revealedCells = 0;

            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    if (Grid[i, j].Visited && !Grid[i, j].Live)
                        revealedCells++;
                }
            }

            return revealedCells == cellsToReveal;
        }
    }
}
