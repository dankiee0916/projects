﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Minesweeper;

namespace MinesweeperGUI
{
    // HighScoresForm to display the top high scores
    public partial class HighScoresForm : Form
    {
        // Use the Application Data folder for a more reliable file path
        private static readonly string HighScoresFile = Path.Combine(Application.StartupPath, "highscores.txt");

        public HighScoresForm()
        {
            InitializeComponent();
            LoadHighScores(); // Load high scores when the form is initialized
        }

        // Load high scores from the file and display in the ListBox
        private void LoadHighScores()
        {
            MessageBox.Show($"High scores file path: {HighScoresFile}"); // Debug message to check file path

            if (File.Exists(HighScoresFile))
            {
                var lines = File.ReadAllLines(HighScoresFile);
                MessageBox.Show($"File content: {string.Join(Environment.NewLine, lines)}"); // Debug message to show file content

                // Use LINQ to filter and sort the high scores
                var highScores = lines
                    .Select(line => {
                        var parts = line.Split(',');
                        if (parts.Length == 5)
                        {
                            return new PlayerStats(parts[0], parts[1], TimeSpan.Parse(parts[2]), int.Parse(parts[3]), bool.Parse(parts[4]));
                        }
                        else
                        {
                            return null; // Skip invalid lines
                        }
                    })
                    .Where(score => score != null)
                    .OrderByDescending(p => p.IsWin)
                    .ThenByDescending(p => p.Score)
                    .ToList();

                highScoresListBox.Items.Clear();
                foreach (var score in highScores)
                {
                    highScoresListBox.Items.Add(score.ToString());
                }

                // Debug message to check if scores are loaded
                MessageBox.Show($"Loaded {highScores.Count} high scores.");
            }
            else
            {
                // Ensure the directory exists
                Directory.CreateDirectory(Path.GetDirectoryName(HighScoresFile));
                MessageBox.Show("High scores file not found. Creating a new one.");
                File.Create(HighScoresFile).Dispose(); // Ensure the file is created
            }
        }

        // Save a high score to the file
        public static void SaveHighScore(PlayerStats playerStats)
        {
            MessageBox.Show("Attempting to save high score..."); // Debug message

            var line = $"{playerStats.PlayerInitials},{playerStats.DifficultyLevel},{playerStats.TimeElapsed},{playerStats.Score},{playerStats.IsWin}";
            File.AppendAllLines(HighScoresFile, new[] { line });

            // Debug message to confirm the score is saved
            MessageBox.Show($"High score saved: {line}");
        }
    }
}
