namespace MinesweeperGUI
{
    public partial class DifficultyForm : Form
    {
        public DifficultyForm()
        {
            InitializeComponent();
        }

        private void btnPlayGame_Click(object sender, EventArgs e)
        {
            // Determine the selected difficulty level
            int gridSize;
            if (radioEasy.Checked)
                gridSize = 10; // Example size
            else if (radioModerate.Checked)
                gridSize = 15; // Example size
            else
                gridSize = 20; // Example size

            MessageBox.Show($"Difficulty selected: {gridSize}");

            // Open the secondary form with the selected difficulty
            MinesweeperGUI secondaryForm = new MinesweeperGUI(gridSize);
            secondaryForm.Show();
            MessageBox.Show("Secondary form should now be visible.");
            this.Hide();
        }

        // Event handler to show high scores
        private void btnHighScores_Click(object sender, EventArgs e)
        {
            new HighScoresForm().ShowDialog();
        }
    }
}
