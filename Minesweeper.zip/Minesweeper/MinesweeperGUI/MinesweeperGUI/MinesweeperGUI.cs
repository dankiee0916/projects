﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Minesweeper;

namespace MinesweeperGUI
{
    public partial class MinesweeperGUI : Form
    {
        private int gridSize; // Size of the game grid
        private Board gameBoard; // The game board object
        private DateTime startTime; // Start time to calculate elapsed time

        // Constructor to initialize the form with a specified grid size
        public MinesweeperGUI(int size)
        {
            InitializeComponent();
            gridSize = size;
            gameBoard = new Board(gridSize, 0.02f); // Set a default difficulty of 10% mines
            gameBoard.SetupLiveNeighbors(); // Initialize the board with mines
            gameBoard.CalculateLiveNeighbors(); // Calculate the number of live neighbors for each cell
            InitializeGrid(); // Create the grid of buttons
            startTime = DateTime.Now; // Set the start time for the game
        }

        // Method to initialize the grid of buttons on the panel
        private void InitializeGrid()
        {
            panelGrid.Controls.Clear(); // Clear any existing controls on the panel
            int buttonSize = panelGrid.Width / gridSize; // Calculate the size of each button

            // Loop through each row and column to create buttons
            for (int row = 0; row < gridSize; row++)
            {
                for (int col = 0; col < gridSize; col++)
                {
                    Button btn = new Button
                    {
                        Width = buttonSize,
                        Height = buttonSize,
                        Left = col * buttonSize,
                        Top = row * buttonSize,
                        Tag = new Tuple<int, int>(row, col) // Store the row and column in the Tag property
                    };
                    btn.Click += Btn_Click; // Add click event handler for the button
                    btn.MouseUp += Btn_MouseUp; // Add mouse up event handler for right-click flagging
                    panelGrid.Controls.Add(btn); // Add the button to the panel
                }
            }
        }

        // Event handler for button click
        private void Btn_Click(object sender, EventArgs e)
        {
            if (sender is Button btn)
            {
                var coordinates = (Tuple<int, int>)btn.Tag;
                int row = coordinates.Item1;
                int col = coordinates.Item2;

                if (gameBoard.Grid[row, col].Live)
                {
                    // Game over, reveal all bombs
                    RevealAllBombs();
                    MessageBox.Show("Boom! You hit a bomb. Game over.");

                    string initials = Prompt.ShowDialog("Enter your initials", "High Score");
                    TimeSpan elapsedTime = DateTime.Now - startTime;
                    int score = CalculateScore(elapsedTime);
                    PlayerStats playerStats = new PlayerStats(initials, "Medium", elapsedTime, score, false); // Track as loss
                    HighScoresForm.SaveHighScore(playerStats);

                    Application.Exit(); // Automatically close the application
                }
                else
                {
                    gameBoard.FloodFill(row, col); // Reveal the cells using flood fill
                    UpdateButtonStates(); // Update the button states to reflect the game board
                    if (gameBoard.AllNonBombCellsRevealed())
                    {
                        TimeSpan elapsedTime = DateTime.Now - startTime;
                        MessageBox.Show($"Congratulations! You've cleared all safe cells. You win! Time: {elapsedTime}");

                        string initials = Prompt.ShowDialog("Enter your initials", "High Score");
                        int score = CalculateScore(elapsedTime);
                        PlayerStats playerStats = new PlayerStats(initials, "Medium", elapsedTime, score, true); // Track as win
                        HighScoresForm.SaveHighScore(playerStats);

                        MessageBox.Show("You can now check the high scores."); // Debug message
                        new HighScoresForm().ShowDialog();
                        Application.Exit(); // Automatically close the application
                    }
                }
            }
        }

        // Method to calculate the score based on the elapsed time
        private int CalculateScore(TimeSpan elapsedTime)
        {
            return (int)(1000 / elapsedTime.TotalSeconds); // Example score calculation
        }

        // Event handler for button mouse up (used for right-click flagging)
        private void Btn_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && sender is Button btn)
            {
                // Toggle flagging on right-click
                if (btn.Text == "F")
                {
                    btn.Text = ""; // Remove flag
                }
                else
                {
                    btn.Text = "F"; // Add flag
                }
            }
        }

        // Method to reveal all bombs when the game is over
        private void RevealAllBombs()
        {
            foreach (Button btn in panelGrid.Controls)
            {
                var coordinates = (Tuple<int, int>)btn.Tag;
                int row = coordinates.Item1;
                int col = coordinates.Item2;

                if (gameBoard.Grid[row, col].Live)
                {
                    btn.Text = "*"; // Show bomb
                    btn.BackColor = Color.Red; // Change background color to red
                }
            }
        }

        // Method to update the button states based on the game board
        private void UpdateButtonStates()
        {
            foreach (Button btn in panelGrid.Controls)
            {
                var coordinates = (Tuple<int, int>)btn.Tag;
                int row = coordinates.Item1;
                int col = coordinates.Item2;

                var cell = gameBoard.Grid[row, col];
                if (cell.Visited)
                {
                    if (cell.LiveNeighbors > 0)
                    {
                        btn.Text = cell.LiveNeighbors.ToString(); // Show the number of live neighbors
                        btn.BackColor = Color.LightGray; // Change background color to light gray
                    }
                    else
                    {
                        btn.Text = ""; // Show empty cell
                        btn.BackColor = Color.White; // Change background color to white
                    }
                    btn.Enabled = false; // Disable the button
                }
            }
        }
    }

    // Helper class for prompting the user to enter initials
    public static class Prompt
    {
        public static string ShowDialog(string text, string caption)
        {
            Form prompt = new Form()
            {
                Width = 500,
                Height = 150,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = FormStartPosition.CenterScreen
            };
            Label textLabel = new Label() { Left = 50, Top = 20, Text = text };
            TextBox textBox = new TextBox() { Left = 50, Top = 50, Width = 400 };
            Button confirmation = new Button() { Text = "Ok", Left = 350, Width = 100, Top = 70 };
            confirmation.Click += (sender, e) => { prompt.Close(); };
            prompt.Controls.Add(textBox);
            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(textLabel);
            prompt.AcceptButton = confirmation;

            return prompt.ShowDialog() == DialogResult.OK ? textBox.Text : "";
        }
    }
}
