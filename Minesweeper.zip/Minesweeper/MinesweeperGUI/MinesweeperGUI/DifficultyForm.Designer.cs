﻿namespace MinesweeperGUI
{
    partial class DifficultyForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnPlayGame = new Button();
            radioEasy = new RadioButton();
            radioModerate = new RadioButton();
            radioDifficult = new RadioButton();
            btnHighScores = new Button();
            SuspendLayout();
            // 
            // btnPlayGame
            // 
            btnPlayGame.Location = new Point(65, 218);
            btnPlayGame.Name = "btnPlayGame";
            btnPlayGame.Size = new Size(75, 23);
            btnPlayGame.TabIndex = 0;
            btnPlayGame.Text = "Play Game";
            btnPlayGame.UseVisualStyleBackColor = true;
            btnPlayGame.Click += btnPlayGame_Click;
            // 
            // radioEasy
            // 
            radioEasy.AutoSize = true;
            radioEasy.Location = new Point(65, 24);
            radioEasy.Name = "radioEasy";
            radioEasy.Size = new Size(48, 19);
            radioEasy.TabIndex = 1;
            radioEasy.TabStop = true;
            radioEasy.Text = "Easy";
            radioEasy.UseVisualStyleBackColor = true;
            // 
            // radioModerate
            // 
            radioModerate.AutoSize = true;
            radioModerate.Location = new Point(65, 77);
            radioModerate.Name = "radioModerate";
            radioModerate.Size = new Size(76, 19);
            radioModerate.TabIndex = 2;
            radioModerate.TabStop = true;
            radioModerate.Text = "Moderate";
            radioModerate.UseVisualStyleBackColor = true;
            // 
            // radioDifficult
            // 
            radioDifficult.AutoSize = true;
            radioDifficult.Location = new Point(65, 137);
            radioDifficult.Name = "radioDifficult";
            radioDifficult.Size = new Size(67, 19);
            radioDifficult.TabIndex = 3;
            radioDifficult.TabStop = true;
            radioDifficult.Text = "Difficult";
            radioDifficult.UseVisualStyleBackColor = true;
            // 
            // btnHighScores
            // 
            btnHighScores.Location = new Point(65, 261);
            btnHighScores.Name = "btnHighScores";
            btnHighScores.Size = new Size(75, 23);
            btnHighScores.TabIndex = 4;
            btnHighScores.Text = "HighScores";
            btnHighScores.UseVisualStyleBackColor = true;
            btnHighScores.Click += btnHighScores_Click;
            // 
            // DifficultyForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(205, 312);
            Controls.Add(btnHighScores);
            Controls.Add(radioDifficult);
            Controls.Add(radioModerate);
            Controls.Add(radioEasy);
            Controls.Add(btnPlayGame);
            Name = "DifficultyForm";
            Text = "Select Difficulty";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnPlayGame;
        private RadioButton radioEasy;
        private RadioButton radioModerate;
        private RadioButton radioDifficult;
        private Button btnHighScores;
    }
}
