﻿/*
 * Francisco Gonzalez
 * CST-150
 * Help from Activity 6 CST-150
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cisco_s_Ice_Cream_Shop.Models
{
    internal class InvItem
    {
        public InvItem()
        {
        }

        // Define the Properties
        public string Flavor { get; set; }
        public string Size { get; set; }
        public string Cone { get; set; }
        public double Price { get; set; }
        public int Qty { get; set; }

        public InvItem(string flavor, string size, string cone, double price, int qty)
        {
            // Constructor is initializing the Properties
            Flavor = flavor;
            Size = size;
            Cone = cone;
            Price = price;
            Qty = qty;
        }
    }
}
