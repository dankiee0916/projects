/*
 * Francisco Gonzalez
 * CST-150
 * Milestone Project
 * Mixture of my own work and help from Activity 6 and 7 CST-150
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Cisco_s_Ice_Cream_Shop.BusinessLayer;
using Cisco_s_Ice_Cream_Shop.Models;
using Cisco_s_Ice_Cream_Shop.PresentationLayer;

namespace Cisco_s_Ice_Cream_Shop
{
    public partial class FrmMain : Form
    {
        // Create the class level object
        // This is called an inventory reference variable
        // This is our master inventory object that MUST
        // always contain the most update-to-date inventory
        List<InvItem> invItem = new List<InvItem>();
        List<InvItem> invSearch = new List<InvItem>();

        // Property
        public int SelectedGridIndex { get; set; }

        public FrmMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Populate the grid when the  view all button is clicked
        /// Use this even handler to "Bind a DataGrid
        /// control to List of Object".
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        private void PopulateGrid_ClickEventHandler(object sender, EventArgs e)
        {
            btnDecrease.Visible = true;
            btnIncrease.Visible = true;

            // Instantiate the business class and get all the inventory items
            // from the text file. 
            Inventory readInv = new Inventory();
            invItem = readInv.ReadInventory(invItem);

            Console.WriteLine("Number of items in invItem: " + invItem.Count);
            // Construct the file path
            string dirLoc = Path.Combine(Application.StartupPath, "Data", "inventory.txt");

            // Check if the file exists before attempting to read it
            if (File.Exists(dirLoc))
            {
                // Bind the object (invItem) to the gridview DataSource
                dgvShowInventory.DataSource = invItem;

                Console.WriteLine("Number of columns in DataGridView: " + dgvShowInventory.Columns.Count);
                Console.WriteLine("Number of rows in DataGridView: " + dgvShowInventory.Rows.Count);
                // What if we don't like the names in the header of the GridView?
                // Iterate through the header one column at a time
                // and change the header names. 
                foreach (DataGridViewColumn column in dgvShowInventory.Columns)
                {
                    // Switch statement to change header text
                    // column.Index starts at 0 - end count. 
                    switch (column.Index)
                    {
                        case 0:
                            column.HeaderText = "Flavor";
                            break;
                        case 1:
                            column.HeaderText = "Size";
                            break;
                        case 2:
                            column.HeaderText = "Cone";
                            break;
                        case 3:
                            column.HeaderText = "Price";
                            // Format the "Price" column as currency
                            column.DefaultCellStyle.Format = "C2";
                            // All numbers must be right-justified
                            column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            break;
                        case 4:
                            column.HeaderText = "Quantity";
                            // Number format with nothing to the right of the decimal
                            column.DefaultCellStyle.Format = "N0";
                            //All numbers must be right justified
                            column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            break;

                        default:
                            // Show a message indicating something did not work correctly.
                            MessageBox.Show("Invalid column whas trying to be accessed!");
                            break;
                    }
                }
            }
            else
            {
                MessageBox.Show("The inventory.txt file is missing.");
            }
            dgvShowInventory.Refresh();
        }
        /// <summary>
        /// Search Event Handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSearch_ClickEvent(object sender, EventArgs e)
        {
            // List in the Type Column for a match If there is 
            // a match or multiple matches then we show the match(s)
            // in the data grid view
            string searchFor = txtSearch.Text;
            // Since the searching is logic = we need to do this
            // in the Business Layer. 
            Inventory businessLayer = new Inventory();
            // Search for the match and put the results in the search list
            invSearch = businessLayer.SearchItem(invItem, invSearch, searchFor);
            //Populate data grid view
            dgvShowInventory.DataSource = null;
            dgvShowInventory.DataSource = invSearch;
            dgvShowInventory.Refresh();
            // Send this invSearch over to the secondary form to be displayed
            FrmSecondary frmSecondary = new FrmSecondary(invSearch);
            // Now we need to show the form
            // .show() methods shows the form in a non model form. This
            // means you can click on the parent form   
            // .ShowDialog() methods shows the form modally, meaning
            // you cannot go to the parent form. 
            frmSecondary.Show();
        }

        /// <summary>
        /// Delete an item from our inventory (master inventory list)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnDeleteItem_EventHandler(object sender, EventArgs e)
        {
            // We already know the selected row which is the index
            // Make sure to remove the item from the master inventory
            invItem.RemoveAt(SelectedGridIndex);
            // We have to be careful when deleteing items since we 
            // will get an out of range exception since the datasource
            // is bound to the initial number of rows.
            // Therefore, we can not just refresh the data grid view
            // reset the datasource by clearing it out and setting it to null
            dgvShowInventory.DataSource = null;
            // last step is to bind the new data back to the Data Grid View
            dgvShowInventory.DataSource = invItem;
            // Key --> invItem still has the master inventory!!!
            dgvShowInventory.Refresh();
        }

        /// <summary>
        /// Event Handler to manage button to increase quantity
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnIncQty_ClickEventHandler(object sender, EventArgs e)
        {
            // Make sure the logic is not in the presentation layer
            // Inc qty in Inventory Class
            // Instantiate the inventory class so we can use the inc qty method
            Inventory incQty = new Inventory();
            // Invoke the method to inc qty and ge tthe master list back
            invItem = incQty.IncQtyValue(invItem, SelectedGridIndex);
            // Since the list contains the master Inventory
            // Refresh the data in teh Data Grid View
            // Since we have already bound the List to the Data Grid View
            dgvShowInventory.Refresh();
        }

        /// <summary>
        /// Event Handler to manage button to decrease quantity
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnDecQty_ClickEventHandler(object sender, EventArgs e)
        {
            // Make sure the logic is not in the presentation layer
            // Dec qty in Inventory Class
            // Instantiate the inventory class so we can use the inc qty method
            Inventory decQty = new Inventory();
            // Invoke the method to dec qty and get the master list back
            invItem = decQty.DecQtyValue(invItem, SelectedGridIndex);
            // Since the list contains the master Inventory
            // Refresh the data in teh Data Grid View
            // Since we have already bound the List to the Data Grid View
            dgvShowInventory.Refresh();
        }

        /// <summary>
        /// Event Handler to manage click events of Data Grid View
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GridView_ClickEventHandler(object sender, EventArgs e)
        {
            // Get the selected row
            SelectedGridIndex = dgvShowInventory.CurrentRow.Index;

            // Check if the index is valid
            if (SelectedGridIndex >= 0 && SelectedGridIndex < invItem.Count)
            {
                // Now we also know the index into the List
                // to get all our information.
            }
            dgvShowInventory.Refresh();
        }



    }
}