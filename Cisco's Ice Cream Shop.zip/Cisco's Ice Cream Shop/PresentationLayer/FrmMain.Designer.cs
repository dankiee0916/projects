﻿namespace Cisco_s_Ice_Cream_Shop
{
    partial class FrmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            lblName = new Label();
            btnRemoveFlavor = new Button();
            btnView = new Button();
            selectFileDialog = new OpenFileDialog();
            dgvShowInventory = new DataGridView();
            btnIncrease = new Button();
            btnDecrease = new Button();
            txtSearch = new TextBox();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvShowInventory).BeginInit();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.BackColor = Color.Crimson;
            lblName.BorderStyle = BorderStyle.FixedSingle;
            lblName.Font = new Font("Britannic Bold", 14.25F, FontStyle.Underline, GraphicsUnit.Point);
            lblName.ForeColor = Color.White;
            lblName.ImageAlign = ContentAlignment.TopCenter;
            lblName.Location = new Point(393, 12);
            lblName.Name = "lblName";
            lblName.Size = new Size(307, 29);
            lblName.TabIndex = 0;
            lblName.Text = "Cisco's Ice Cream Inventory";
            lblName.TextAlign = ContentAlignment.TopCenter;
            // 
            // btnRemoveFlavor
            // 
            btnRemoveFlavor.BackColor = Color.Crimson;
            btnRemoveFlavor.FlatStyle = FlatStyle.Flat;
            btnRemoveFlavor.Font = new Font("Britannic Bold", 14.25F, FontStyle.Underline, GraphicsUnit.Point);
            btnRemoveFlavor.ForeColor = Color.White;
            btnRemoveFlavor.Location = new Point(24, 267);
            btnRemoveFlavor.Margin = new Padding(3, 4, 3, 4);
            btnRemoveFlavor.Name = "btnRemoveFlavor";
            btnRemoveFlavor.Size = new Size(115, 47);
            btnRemoveFlavor.TabIndex = 3;
            btnRemoveFlavor.Text = "Remove Flavor";
            btnRemoveFlavor.UseVisualStyleBackColor = false;
            btnRemoveFlavor.Click += BtnDeleteItem_EventHandler;
            // 
            // btnView
            // 
            btnView.BackColor = Color.Crimson;
            btnView.Cursor = Cursors.Hand;
            btnView.FlatStyle = FlatStyle.Flat;
            btnView.Font = new Font("Britannic Bold", 14.25F, FontStyle.Underline, GraphicsUnit.Point);
            btnView.ForeColor = Color.White;
            btnView.Location = new Point(24, 176);
            btnView.Margin = new Padding(3, 4, 3, 4);
            btnView.Name = "btnView";
            btnView.Size = new Size(115, 47);
            btnView.TabIndex = 5;
            btnView.Text = "View All Flavors/Cones";
            btnView.UseVisualStyleBackColor = false;
            btnView.Click += PopulateGrid_ClickEventHandler;
            // 
            // selectFileDialog
            // 
            selectFileDialog.FileName = "openFileDialog1";
            // 
            // dgvShowInventory
            // 
            dgvShowInventory.AllowUserToResizeColumns = false;
            dgvShowInventory.AllowUserToResizeRows = false;
            dgvShowInventory.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvShowInventory.BackgroundColor = Color.Crimson;
            dgvShowInventory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvShowInventory.Location = new Point(360, 85);
            dgvShowInventory.Margin = new Padding(3, 4, 3, 4);
            dgvShowInventory.Name = "dgvShowInventory";
            dgvShowInventory.RowHeadersWidth = 51;
            dgvShowInventory.RowTemplate.Height = 25;
            dgvShowInventory.Size = new Size(626, 431);
            dgvShowInventory.TabIndex = 7;
            dgvShowInventory.Click += GridView_ClickEventHandler;
            // 
            // btnIncrease
            // 
            btnIncrease.BackColor = Color.Crimson;
            btnIncrease.FlatStyle = FlatStyle.Flat;
            btnIncrease.Font = new Font("Britannic Bold", 14.25F, FontStyle.Underline, GraphicsUnit.Point);
            btnIncrease.ForeColor = Color.White;
            btnIncrease.Location = new Point(24, 371);
            btnIncrease.Margin = new Padding(3, 4, 3, 4);
            btnIncrease.Name = "btnIncrease";
            btnIncrease.Size = new Size(115, 47);
            btnIncrease.TabIndex = 8;
            btnIncrease.Text = "Increase";
            btnIncrease.UseVisualStyleBackColor = false;
            btnIncrease.Visible = false;
            btnIncrease.Click += BtnIncQty_ClickEventHandler;
            // 
            // btnDecrease
            // 
            btnDecrease.BackColor = Color.Crimson;
            btnDecrease.FlatStyle = FlatStyle.Flat;
            btnDecrease.Font = new Font("Britannic Bold", 14.25F, FontStyle.Underline, GraphicsUnit.Point);
            btnDecrease.ForeColor = Color.White;
            btnDecrease.Location = new Point(24, 469);
            btnDecrease.Margin = new Padding(3, 4, 3, 4);
            btnDecrease.Name = "btnDecrease";
            btnDecrease.Size = new Size(120, 47);
            btnDecrease.TabIndex = 9;
            btnDecrease.Text = "Decrease";
            btnDecrease.UseVisualStyleBackColor = false;
            btnDecrease.Visible = false;
            btnDecrease.Click += BtnDecQty_ClickEventHandler;
            // 
            // txtSearch
            // 
            txtSearch.BackColor = Color.Crimson;
            txtSearch.ForeColor = Color.White;
            txtSearch.Location = new Point(146, 97);
            txtSearch.Margin = new Padding(3, 4, 3, 4);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(108, 27);
            txtSearch.TabIndex = 11;
            // 
            // button2
            // 
            button2.BackColor = Color.Crimson;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Britannic Bold", 14.25F, FontStyle.Underline, GraphicsUnit.Point);
            button2.ForeColor = Color.White;
            button2.Location = new Point(24, 85);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(115, 47);
            button2.TabIndex = 12;
            button2.Text = "Search";
            button2.UseVisualStyleBackColor = false;
            button2.Click += BtnSearch_ClickEvent;
            // 
            // FrmMain
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1000, 760);
            Controls.Add(button2);
            Controls.Add(txtSearch);
            Controls.Add(btnDecrease);
            Controls.Add(btnIncrease);
            Controls.Add(dgvShowInventory);
            Controls.Add(btnView);
            Controls.Add(btnRemoveFlavor);
            Controls.Add(lblName);
            Margin = new Padding(3, 4, 3, 4);
            Name = "FrmMain";
            Text = "Cisco's Ice Cream Shop";
            ((System.ComponentModel.ISupportInitialize)dgvShowInventory).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblName;
        private Button btnRemoveFlavor;
        private Button btnView;
        private OpenFileDialog selectFileDialog;
        private DataGridView dgvShowInventory;
        private Button btnIncrease;
        private Button btnDecrease;
        private TextBox txtSearch;
        private Button button2;
    }
}