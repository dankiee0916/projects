﻿/*
 * Francisco Gonzalez
 * CST-150
 * Help from CST-150 Activity 6!
 */
using Cisco_s_Ice_Cream_Shop.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cisco_s_Ice_Cream_Shop.BusinessLayer
{
    internal class Inventory
    {
        // The purpose of this class is to read the text file
        // into a List and then pass the list to the FrmMain.cs
        public List<InvItem> ReadInventory(List<InvItem> invItems)
        {
            string dirLoc = Path.Combine(Application.StartupPath, "Data", "inventory.txt");

            try
            {
                using (var str = File.OpenText(dirLoc))
                {
                    foreach (string line in File.ReadLines(dirLoc, Encoding.UTF8))
                    {
                        string[] rowData = line.Split(",");
                        try
                        {
                            // ... (previous code)
                            invItems.Add(new InvItem(
                                rowData[0].ToString().Trim(),
                                rowData[1].ToString().Trim(),
                                rowData[2].ToString().Trim(),
                                Convert.ToDouble(rowData[3], CultureInfo.InvariantCulture), // Use CultureInfo.InvariantCulture
                                Convert.ToInt32(rowData[4])
                            ));
                        }
                        catch (FormatException ex)
                        {
                            Console.WriteLine($"Error converting data: {ex.Message}");
                            // Handle or log the error as needed
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An unexpected error occurred: {ex.Message}");
            }

            return invItems;
        }
        // End of Read Inventory Method


        /// <summary>
        /// Inc inventory in the List and then return the updated list
        /// </summary>
        /// <param name="invItems"></param>
        /// <param name="selectedRowIndex"></param>
        /// <returns></returns>
        public List<InvItem> IncQtyValue(List<InvItem> invItems, int selectedRowIndex)
        {

            ++invItems[selectedRowIndex].Qty;
            return invItems;
        }

        /// <summary>
        /// Dec inventory in the List and then return the updated list
        /// </summary>
        /// <param name="invItems"></param>
        /// <param name="selectedRowIndex"></param>
        /// <returns></returns>
        public List<InvItem> DecQtyValue(List<InvItem> invItems, int selectedRowIndex)
        {

            --invItems[selectedRowIndex].Qty;
            return invItems;
        }

        /// <summary>
        /// Search the items in the main inventory List and return the New Search List
        /// </summary>
        /// <param name="invItems"></param>
        /// <param name="invSearch"></param>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        public List<InvItem> SearchItem(List<InvItem> invItems, List<InvItem> invSearch, string searchCriteria)
        {
            //  Make sure the inv Search list is cleared before we start
            invSearch.Clear();
            // Iterate over the main inventory and see if we can find
            // any matches to the search criteria
            foreach (InvItem item in invItems)
            {
                // Let's test for a match
                if (item.Flavor.ToLower().Contains(searchCriteria.ToLower()))
                {
                    // If an item was found add it to the list
                    invSearch.Add(item);
                }
            }
            // Return the end result of the search
            return invSearch;
        }


    }
}